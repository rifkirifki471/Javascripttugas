const namadepan = "Rifki";
const namabelakang = "darmawan";
const TanggalLahir = "21 November 1998"
const TempatLahir = "Makassar"
const umur = "24";
const alamat = "Kendari"

const biodata = `Nama saya ${namadepan} ${namabelakang} Tempat Tanggal Lahir ${TanggalLahir} ${TempatLahir} Umur ${umur} alamat ${alamat} `

console.log(biodata);