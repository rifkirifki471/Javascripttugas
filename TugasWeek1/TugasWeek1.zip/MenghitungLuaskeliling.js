let Panjang = 100;
let lebar = 75;

let Luas = Panjang + lebar;
let Keliling = 2 * (Panjang + lebar);

console.log(Luas);
console.log(Keliling);