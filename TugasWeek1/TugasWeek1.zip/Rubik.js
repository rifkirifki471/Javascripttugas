let panjang = 5.5;
let lebar = 5.5;
let tinggi = 5.5;

let volume = panjang * lebar * tinggi;
let luasAlas = panjang * lebar;

console.log(volume);
console.log(luasAlas);